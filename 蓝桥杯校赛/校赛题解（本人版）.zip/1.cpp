#include <set>
#include <algorithm>
#include <stdio.h>
#include <iostream>

using namespace std;

set<int> Set;

int main(void)
{
	int n = 0;
	while (cin >> n)
	{
		if (n == -1)
			return 0;
		for (int i = 0; i < n; i++)
		{
			int temp;
			cin >> temp;
			Set.insert(temp);
		}

		for (set<int>::iterator it = Set.begin(); it != Set.end(); it++)
		{
			cout << *it << " ";
		}
		cout << endl;
	}
	return 0;
}