#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <algorithm>

using namespace std;

typedef struct{
	double x, y;
}Point;

vector<Point> pointSet;

double calcLen(Point& p1, Point& p2)
{
	double x1 = p1.x;
	double y1 = p1.y;
	double x2 = p2.x;
	double y2 = p2.y;
	return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

double calcTotalLen()
{
	double len = 0;
	for (vector<Point>::iterator it = ++pointSet.begin(); it < pointSet.end(); it++)
		len += calcLen(*it, *(it - 1));
	return len;
}

Point findMid(double totalLen)
{
	Point ans;
	Point startP;
	double alpha = 0;
	double len = 0;
	double deltaL = 0;
	double halfLen = totalLen/2;
	for (vector<Point>::iterator it = ++pointSet.begin(); it < pointSet.end(); it++)
	{
		Point preP = *(it - 1);
		deltaL = halfLen -len;
		len += calcLen(*it, preP);
		if (len >= halfLen)
		{
			startP = preP;
			alpha = atan((it->y - preP.y) / (it->x - preP.x));
			break;
		}
	}
	ans.x = startP.x + deltaL*cos(alpha);
	ans.y = startP.y + deltaL*sin(alpha);
	return ans;
}

int main(void)
{
	int n = 0;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		double a, b;
		cin >> a >> b;
		Point p;
		p.x = a;
		p.y = b;
		pointSet.push_back(p);
	}
	Point ans = findMid(calcTotalLen());
	printf("%.1lf %.1lf\n", ans.x, ans.y);
	return 0;
}
