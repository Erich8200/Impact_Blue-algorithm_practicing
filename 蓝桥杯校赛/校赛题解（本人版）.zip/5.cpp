#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <algorithm>
#include <string>
#include <stdio.h>
#include <vector>
#include <unordered_set>

using namespace std;

int vis[26];
string pass3;
char mat[5][5];

int main(void)
{
	freopen("input0.txt", "r", stdin);

	string orig_pass;
	cin >> orig_pass;

	//Step 2
	for (int i = 0; i < orig_pass.length(); i++)
	{
		if (orig_pass.at(i) == 'J')
			orig_pass.at(i) = 'I';
	}

	//Step 3
	for (int i = 0; i < orig_pass.length(); i++)
	{
		char tmp = orig_pass.at(i);
		if (pass3.find(orig_pass[i]) == string::npos)
		{
			pass3.push_back(tmp);
			vis[tmp - 'A'] = true;
		}
	}

	int i, j;
	string::iterator it = pass3.begin();
	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 5; j++)
		{
			if (it == pass3.end())
				break;
			mat[i][j] = *it;
			it++;
		}
		if (it == pass3.end())
			break;
	}

	int index = 0;
	int k = i, l = j;
	while (index < 26 && k < 5 && l < 5)
	{
		if (!vis[index] && index != 'J' - 'A')
		{
			mat[k][l] = 'A' + index;
			l++;
		}
		if (l == 5)
		{
			l = 0;
			k++;
		}

		index++;
	}

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			cout << mat[i][j];
		}
		cout << endl;
	}

	fclose(stdin);
	return 0;
}
