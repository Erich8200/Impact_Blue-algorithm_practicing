#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <vector>

using namespace std;

vector< pair<int, int> > pairSet;

int main(void)
{
	int n = 0;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		int a,b;
		cin >> a >> b;
		pairSet.push_back(pair<int, int>(a, b));
	}
	
	int count = 0;
	
	for (int i = 0; i < pairSet.size(); i++)
		for (int j = i + 1; j < pairSet.size(); j++)
			if (pairSet[i].first + pairSet[j].first == pairSet[i].second + pairSet[j].second)
				count += 1;
	
	cout << count << endl;

	return 0;
}
