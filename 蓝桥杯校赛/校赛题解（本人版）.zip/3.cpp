#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <algorithm>
#include <string>
#include <stdio.h>
#include <queue>
#define N 10000

using namespace std;

int Map[N + 2][N + 2];
bool vis[N + 2][N + 2];

typedef struct
{
	int curRow, curCol, step;
} Node;

int dirRow[] = { -1,0,1,0 };
int dirCol[] = { 0,1,0,-1 };

int BFS(int w, int h, int sRow, int sCol, int tgt)
{
	int ans = 0;
	queue<Node> Q;
	Node root;
	root.curRow = sRow;
	root.curCol = sCol;
	root.step = 0;
	Q.push(root);
	vis[sRow][sCol] = true;
	while (!Q.empty())
	{
		Node curNode = Q.front();
		Q.pop();
		if (Map[curNode.curRow][curNode.curCol] == tgt)
		{
			ans = curNode.step;
			break;
		}

		for (int i = 0; i < 4; i++)
		{
			int newRow = curNode.curRow + dirRow[i];
			int newCol = curNode.curCol + dirCol[i];
			int curStep = curNode.step;
			if (newRow >= 0 && newRow < h && newCol >= 0 && newCol < w && !vis[newRow][newCol])
			{
				Node newNode;
				newNode.curRow = newRow;
				newNode.curCol = newCol;
				newNode.step = curStep + 1;
				Q.push(newNode);
				vis[newRow][newCol] = true;
			}
		}
	}
	return ans;
}

void build(int w, int h)
{
	int num = 1;
	for (int i = 0; i < h; i++)
	{
		if (i % 2 == 0)
		{
			for (int j = 0; j < w; j++)
			{
				Map[i][j] = num;
				num += 1;
			}
				
		}
		else
		{
			for (int j = w - 1; j >= 0; j--)
			{
				Map[i][j] = num;
				num += 1;
			}			
		}
	}
}

void searchStart(int num, int& startRow, int& startCol, int w, int h)
{
	for (int i = 0; i < h; i++)
	{
		for (int j = 0; j < w; j++)
		{
			if (Map[i][j] == num)
			{
				startRow = i;
				startCol = j;
				break;
			}
		}
	}
	return;
}

int main(void)
{
	int w, m, n;
	cin >> w >> m >> n;
	
	int h = max(m, n) / w + 1;

	build(w, h);

	int startRow = 0, startCol = 0;
	searchStart(m, startRow, startCol, w, h);

	cout << BFS(w, h, startRow, startCol, n) << endl;


	//for (int i = 0; i < h; i++)
	//{
	//	for (int j = 0; j < w; j++)
	//	{
	//		cout << Map[i][j] << " ";
	//	}
	//	cout << endl;
	//}



	system("pause");
	return 0;
}
