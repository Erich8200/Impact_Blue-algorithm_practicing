#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <algorithm>
#include <string>
#include <stdio.h>
#include <vector>
#include <map>

using namespace std;

map<char, int> hashMap;
vector<string> strList;
vector< vector<int> > numList;
vector<int> ansList;
vector< vector<int> > decodedNumList;

int main(void)
{
	freopen("input0.txt", "r", stdin);

	hashMap['A'] = hashMap['B'] = hashMap['C'] = 2;
	hashMap['D'] = hashMap['E'] = hashMap['F'] = 3;
	hashMap['G'] = hashMap['H'] = hashMap['I'] = 4;
	hashMap['J'] = hashMap['K'] = hashMap['L'] = 5;
	hashMap['M'] = hashMap['N'] = hashMap['O'] = 6;
	hashMap['P'] = hashMap['Q'] = hashMap['R'] = hashMap['S'] =  7;
	hashMap['T'] = hashMap['U'] = hashMap['V'] = 8;
	hashMap['X'] = hashMap['Y'] = hashMap['Z'] = hashMap['W'] =  9;

	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; i++)
	{
		string temp;
		cin >> temp;
		strList.push_back(temp);
	}

	for (int i = 0; i < m; i++)
	{
		string temp;
		cin >> temp;
		vector<int> numArr;
		for (string::iterator it = temp.begin(); it < temp.end(); it++)
			numArr.push_back(*it - '0');
		numList.push_back(numArr);
	}

	//string----decode---->vector<int>
	for (vector<string>::iterator it = strList.begin(); it < strList.end(); it++)
	{
		vector<int> numArr;
		for (string::iterator itt = it->begin(); itt < it->end(); itt++)
			numArr.push_back(hashMap[*itt]);
		decodedNumList.push_back(numArr);
	}

	for (vector< vector<int> >::iterator it = numList.begin(); it < numList.end(); it++)
	{
		ansList.push_back(count(decodedNumList.begin(), decodedNumList.end(), *it));
	}

	for (int i = 0; i < ansList.size(); i++)
	{
		cout << ansList.at(i) << endl;
	}

	fclose(stdin);
	return 0;
}
