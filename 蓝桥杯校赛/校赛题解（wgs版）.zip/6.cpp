#include<stdio.h>
#include<algorithm>
#include<iostream>
using namespace std;
const int maxn = 100010;
int A[maxn],N;
int len[maxn];
int main(void)
{
	cin >> N;
	for(int i=0;i<N;i++)
	{
		cin >> A[i];
		len[i]=1;
	}
	for(int i=1;i<N;i++)
	{
		for(int k=0;k<i;k++)
		{
			if(A[k]<A[i] && len[k]+1>len[i])
			{
				len[i] = len[k]+1; 
			}
		}
	}
	int ans = N-len[N-1];
	cout << ans;
	return 0;	
} 
