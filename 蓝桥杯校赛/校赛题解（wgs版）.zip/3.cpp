#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int m,n,w;
int x1,y1;
int x2,y2;
void makePoint1()
{
	y1 = (m+w-1)/w;
	if(y1%2==0)
	{
		x1 = w - (m-(y1-1)*w)+1;
	}
	else
	{
		x1 = m-(y1-1)*w;
	}
}
void makePoint2()
{
	y2 = (n+w-1)/w;
	if(y2%2==0)
	{
		x2 = w-(n-(y2-1)*w)+1;
	}
	else 
	{
		x2 = n-(y2-1)*w;
	}
}
int main(void)
{
	cin >> w >> m >> n;
	makePoint1();
	makePoint2();
	int ans = abs(x1-x2)+abs(y1-y2);
	cout << ans; 
	return 0;	
} 
