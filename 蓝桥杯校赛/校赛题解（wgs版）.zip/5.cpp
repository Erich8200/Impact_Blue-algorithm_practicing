#include<iostream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
bool used[26];
bool have[26];
char ans[6][6];
string key;
int main(void)
{
	cin >> key;
	for(int i=0;i<key.length();i++)
	{
		if(key[i]=='J') key[i]='I';
		else
		{
			have[key[i]-'A']=true;
		}
	}
	memset(used,0,sizeof(used));
	used['J'-'A']=true;
	int pos=0;
	for(int i=0;i<key.length();i++)
	{
		int k = key[i]-'A';
		if(have[k]==true&&used[k]==false)
		{
			used[k]=true;
			int x = pos/5;
			int y = pos%5;
			ans[x][y]='A'+k;
			pos++;
		}
	}
	for(int i=0;i<26;i++)
	{
		if(used[i]==false)
		{
			int x = pos/5;
			int y = pos%5;
			ans[x][y]='A'+i;
			pos++;
		}
	}
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			cout << ans[i][j];
		}
		if(i!=5) cout << endl;
	}
	return 0;	
} 

