#include<iostream>
#include<cstdio>
using namespace std;
const int maxn = 1000010;
int A[maxn];
int main(void)
{
	int n;
	cin>>n;
	while(n!=-1)
	{
		for(int i=0;i<n;i++)
		{
			cin >> A[i];
		}
		int pre = 0;
		for(int i=1;i<n;i++)
		{
			if(A[i]!=A[pre])
			{
				A[++pre]=A[i];
			}
			else 
			{
				//
			}
		}
		for(int i=0;i<=pre;i++)
		{
			cout << A[i];
			if(i!=pre) cout <<" "; 
		}
		cin >> n;
	}
	return 0;
} 
