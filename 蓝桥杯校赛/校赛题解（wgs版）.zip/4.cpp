#include<iostream>
#include<algorithm>
#include<map>
#include<string> 
using namespace std;
map<string,string> table;
map<string,int> sum; 
const int maxn = 50010;
int M,N;
string A[maxn];
string B[maxn];
int main(void)
{
	table["A"]=table["B"]=table["C"]="2";
	table["D"]=table["E"]=table["F"]="3";
	table["G"]=table["H"]=table["I"]="4";
	table["J"]=table["K"]=table["L"]="5";
	table["M"]=table["N"]=table["O"]="6";
	table["P"]=table["Q"]=table["R"]=table["S"]="7";
	table["T"]=table["U"]=table["V"]="8";
	table["W"]=table["X"]=table["Y"]=table["Z"]="9";
	cin >> N >> M;
	for(int i=0;i<N;i++) 
	{
		cin >> A[i];
	}
	for(int i=0;i<M;i++)
	{
		cin >> B[i];
		sum[B[i]]=0;
	}
	for(int i=0;i<N;i++)
	{
		string hand = "";
		for(int k=0;k<A[i].length();k++)
		{
			string ch = A[i].substr(k,1);
			ch = table[ch];
			hand+=ch;
		}
		//cout << hand<<endl;
		sum[hand]++;
	}
	for(int i=0;i<M;i++)
	{
		cout << sum[B[i]];
		if(i!=M-1) cout<<" "; 
	} 
	return 0;
}
