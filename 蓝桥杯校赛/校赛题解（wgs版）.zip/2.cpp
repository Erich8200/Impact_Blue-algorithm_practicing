#include<iostream>
#include<algorithm>
#include<cstring>
#include<string.h>
using namespace std;
const int maxn = 1024*1024+10;
int A[26][maxn];
int B[26];
int C[26];
int ans = 0;
string pwd[1010];
string str;
int main(void)
{
	int n;
	cin >> str;
	cin >> n;
	for(int i=0;i<n;i++)
	{
		cin >> pwd[i];
	}
	int len = str.length();
	for(int i=0;i<len;i++)
	{
		char ch = str[i];
		if(i!=0)
		{
			for(int j=0;j<26;j++) 
				A[j][i]=A[j][i-1];
		}
		A[ch-'a'][i]++;
	}
	
	for(int i=0;i<n;i++)//i���� 
	{
		memset(B,0,sizeof(B));
		for(int k=0;k<8;k++)
		{
			B[pwd[i][k]-'a']++;
		}
		for(int k=7;k<len;k++)
		{
			bool flag = true;
			for(int j=0;j<26;j++)
			{
				if(k==7)
				{
					C[j] = A[j][k];
				}
				else
				{
					C[j] = A[j][k]-A[j][k-8];
				}
			}
			for(int j=0;j<26;j++)
			{
				if(C[j]!=B[j])
				{
					flag = false; 
					break;
				}
			}
			if(flag==true) ans++;
		}
	}
	cout << ans;
	return 0;
}
