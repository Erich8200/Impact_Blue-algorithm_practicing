#include<iostream>
#include<algorthm>
#include<cstdio>
using namespace std;
int n
int main(void)
{
	return 0;
}
