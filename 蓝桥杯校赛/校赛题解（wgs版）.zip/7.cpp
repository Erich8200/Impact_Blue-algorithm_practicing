#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
const int maxn = 100000+10;
int n,ans=0;
int X[maxn],Y[maxn];
int main(void)
{
	cin >> n;
	for(int i=0;i<n;i++) cin >>X[i]>>Y[i];
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(X[i]+X[j]==Y[i]+Y[j]) ans++;
		}
	}
	cout << ans;
	return 0;
}
